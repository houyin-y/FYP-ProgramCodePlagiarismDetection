def addition(num1, num2):
    sum = num1 + num2
    return sum