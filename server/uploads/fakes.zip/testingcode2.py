def add(x, y):
    total = x + y
    return total